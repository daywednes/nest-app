<template>
  <div class="content">
    <div class="row">
      <div class="col-md-12">
        <div class="card demo-icons">
          <div class="card-header">
            <h5 class="card-title">100 Awesome Nucleo Icons</h5>
            <p class="card-category">Handcrafted by our friends from
              <a href="https://nucleoapp.com/?ref=1712">NucleoApp</a>
            </p>
          </div>
          <div class="card-body all-icons">
            <div id="icons-wrapper">
              <section>
                <ul>
                  <li>
                    <i class="nc-icon nc-air-baloon"></i>
                    <p>nc-air-baloon</p>
                    <em>\ea01</em><input type="text" maxlength="1" readonly="true" value=""></li>
                  <li>
                    <i class="nc-icon nc-album-2"></i>
                    <p>nc-album-2</p>
                    <em>\ea02</em><input type="text" maxlength="1" readonly="true" value=""></li>
                  <li>
                    <i class="nc-icon nc-alert-circle-i"></i>
                    <p>nc-alert-circle-i</p>
                    <em>\ea04</em><input type="text" maxlength="1" readonly="true" value=""></li>
                  <li>
                    <i class="nc-icon nc-align-center"></i>
                    <p>nc-align-center</p>
                    <em>\ea03</em><input type="text" maxlength="1" readonly="true" value=""></li>
                  <li>
                    <i class="nc-icon nc-align-left-2"></i>
                    <p>nc-align-left-2</p>
                    <em>\ea05</em><input type="text" maxlength="1" readonly="true" value=""></li>
                  <li>
                    <i class="nc-icon nc-ambulance"></i>
                    <p>nc-ambulance</p>
                    <em>\ea06</em><input type="text" maxlength="1" readonly="true" value=""></li>
                  <li>
                    <i class="nc-icon nc-app"></i>
                    <p>nc-app</p>
                    <em>\ea07</em><input type="text" maxlength="1" readonly="true" value=""></li>
                  <li>
                    <i class="nc-icon nc-atom"></i>
                    <p>nc-atom</p>
                    <em>\ea08</em><input type="text" maxlength="1" readonly="true" value=""></li>
                  <li>
                    <i class="nc-icon nc-badge"></i>
                    <p>nc-badge</p>
                    <em>\ea09</em><input type="text" maxlength="1" readonly="true" value=""></li>
                  <li>
                    <i class="nc-icon nc-bag-16"></i>
                    <p>nc-bag-16</p>
                    <em>\ea0a</em><input type="text" maxlength="1" readonly="true" value=""></li>
                  <li>
                    <i class="nc-icon nc-bank"></i>
                    <p>nc-bank</p>
                    <em>\ea0b</em><input type="text" maxlength="1" readonly="true" value=""></li>
                  <li>
                    <i class="nc-icon nc-basket"></i>
                    <p>nc-basket</p>
                    <em>\ea0c</em><input type="text" maxlength="1" readonly="true" value=""></li>
                  <li>
                    <i class="nc-icon nc-bell-55"></i>
                    <p>nc-bell-55</p>
                    <em>\ea0d</em><input type="text" maxlength="1" readonly="true" value=""></li>
                  <li>
                    <i class="nc-icon nc-bold"></i>
                    <p>nc-bold</p>
                    <em>\ea0e</em><input type="text" maxlength="1" readonly="true" value=""></li>
                  <li>
                    <i class="nc-icon nc-book-bookmark"></i>
                    <p>nc-book-bookmark</p>
                    <em>\ea0f</em><input type="text" maxlength="1" readonly="true" value=""></li>
                  <li>
                    <i class="nc-icon nc-bookmark-2"></i>
                    <p>nc-bookmark-2</p>
                    <em>\ea10</em><input type="text" maxlength="1" readonly="true" value=""></li>
                  <li>
                    <i class="nc-icon nc-box-2"></i>
                    <p>nc-box-2</p>
                    <em>\ea11</em><input type="text" maxlength="1" readonly="true" value=""></li>
                  <li>
                    <i class="nc-icon nc-box"></i>
                    <p>nc-box</p>
                    <em>\ea12</em><input type="text" maxlength="1" readonly="true" value=""></li>
                  <li>
                    <i class="nc-icon nc-briefcase-24"></i>
                    <p>nc-briefcase-24</p>
                    <em>\ea13</em><input type="text" maxlength="1" readonly="true" value=""></li>
                  <li>
                    <i class="nc-icon nc-bulb-63"></i>
                    <p>nc-bulb-63</p>
                    <em>\ea14</em><input type="text" maxlength="1" readonly="true" value=""></li>
                  <li>
                    <i class="nc-icon nc-bullet-list-67"></i>
                    <p>nc-bullet-list-67</p>
                    <em>\ea15</em><input type="text" maxlength="1" readonly="true" value=""></li>
                  <li>
                    <i class="nc-icon nc-bus-front-12"></i>
                    <p>nc-bus-front-12</p>
                    <em>\ea16</em><input type="text" maxlength="1" readonly="true" value=""></li>
                  <li>
                    <i class="nc-icon nc-button-pause"></i>
                    <p>nc-button-pause</p>
                    <em>\ea17</em><input type="text" maxlength="1" readonly="true" value=""></li>
                  <li>
                    <i class="nc-icon nc-button-play"></i>
                    <p>nc-button-play</p>
                    <em>\ea18</em><input type="text" maxlength="1" readonly="true" value=""></li>
                  <li>
                    <i class="nc-icon nc-button-power"></i>
                    <p>nc-button-power</p>
                    <em>\ea19</em><input type="text" maxlength="1" readonly="true" value=""></li>
                  <li>
                    <i class="nc-icon nc-calendar-60"></i>
                    <p>nc-calendar-60</p>
                    <em>\ea1a</em><input type="text" maxlength="1" readonly="true" value=""></li>
                  <li>
                    <i class="nc-icon nc-camera-compact"></i>
                    <p>nc-camera-compact</p>
                    <em>\ea1b</em><input type="text" maxlength="1" readonly="true" value=""></li>
                  <li>
                    <i class="nc-icon nc-caps-small"></i>
                    <p>nc-caps-small</p>
                    <em>\ea1c</em><input type="text" maxlength="1" readonly="true" value=""></li>
                  <li>
                    <i class="nc-icon nc-cart-simple"></i>
                    <p>nc-cart-simple</p>
                    <em>\ea1d</em><input type="text" maxlength="1" readonly="true" value=""></li>
                  <li>
                    <i class="nc-icon nc-chart-bar-32"></i>
                    <p>nc-chart-bar-32</p>
                    <em>\ea1e</em><input type="text" maxlength="1" readonly="true" value=""></li>
                  <li>
                    <i class="nc-icon nc-chart-pie-36"></i>
                    <p>nc-chart-pie-36</p>
                    <em>\ea1f</em><input type="text" maxlength="1" readonly="true" value=""></li>
                  <li>
                    <i class="nc-icon nc-chat-33"></i>
                    <p>nc-chat-33</p>
                    <em>\ea20</em><input type="text" maxlength="1" readonly="true" value=""></li>
                  <li>
                    <i class="nc-icon nc-check-2"></i>
                    <p>nc-check-2</p>
                    <em>\ea21</em><input type="text" maxlength="1" readonly="true" value=""></li>
                  <li>
                    <i class="nc-icon nc-circle-10"></i>
                    <p>nc-circle-10</p>
                    <em>\ea22</em><input type="text" maxlength="1" readonly="true" value=""></li>
                  <li>
                    <i class="nc-icon nc-cloud-download-93"></i>
                    <p>nc-cloud-download-93</p>
                    <em>\ea23</em><input type="text" maxlength="1" readonly="true" value=""></li>
                  <li>
                    <i class="nc-icon nc-cloud-upload-94"></i>
                    <p>nc-cloud-upload-94</p>
                    <em>\ea24</em><input type="text" maxlength="1" readonly="true" value=""></li>
                  <li>
                    <i class="nc-icon nc-compass-05"></i>
                    <p>nc-compass-05</p>
                    <em>\ea25</em><input type="text" maxlength="1" readonly="true" value=""></li>
                  <li>
                    <i class="nc-icon nc-controller-modern"></i>
                    <p>nc-controller-modern</p>
                    <em>\ea26</em><input type="text" maxlength="1" readonly="true" value=""></li>
                  <li>
                    <i class="nc-icon nc-credit-card"></i>
                    <p>nc-credit-card</p>
                    <em>\ea27</em><input type="text" maxlength="1" readonly="true" value=""></li>
                  <li>
                    <i class="nc-icon nc-delivery-fast"></i>
                    <p>nc-delivery-fast</p>
                    <em>\ea28</em><input type="text" maxlength="1" readonly="true" value=""></li>
                  <li>
                    <i class="nc-icon nc-diamond"></i>
                    <p>nc-diamond</p>
                    <em>\ea29</em><input type="text" maxlength="1" readonly="true" value=""></li>
                  <li>
                    <i class="nc-icon nc-email-85"></i>
                    <p>nc-email-85</p>
                    <em>\ea2a</em><input type="text" maxlength="1" readonly="true" value=""></li>
                  <li>
                    <i class="nc-icon nc-favourite-28"></i>
                    <p>nc-favourite-28</p>
                    <em>\ea2b</em><input type="text" maxlength="1" readonly="true" value=""></li>
                  <li>
                    <i class="nc-icon nc-glasses-2"></i>
                    <p>nc-glasses-2</p>
                    <em>\ea2c</em><input type="text" maxlength="1" readonly="true" value=""></li>
                  <li>
                    <i class="nc-icon nc-globe-2"></i>
                    <p>nc-globe-2</p>
                    <em>\ea2d</em><input type="text" maxlength="1" readonly="true" value=""></li>
                  <li>
                    <i class="nc-icon nc-globe"></i>
                    <p>nc-globe</p>
                    <em>\ea2e</em><input type="text" maxlength="1" readonly="true" value=""></li>
                  <li>
                    <i class="nc-icon nc-hat-3"></i>
                    <p>nc-hat-3</p>
                    <em>\ea2f</em><input type="text" maxlength="1" readonly="true" value=""></li>
                  <li>
                    <i class="nc-icon nc-headphones"></i>
                    <p>nc-headphones</p>
                    <em>\ea30</em><input type="text" maxlength="1" readonly="true" value=""></li>
                  <li>
                    <i class="nc-icon nc-html5"></i>
                    <p>nc-html5</p>
                    <em>\ea31</em><input type="text" maxlength="1" readonly="true" value=""></li>
                  <li>
                    <i class="nc-icon nc-image"></i>
                    <p>nc-image</p>
                    <em>\ea32</em><input type="text" maxlength="1" readonly="true" value=""></li>
                  <li>
                    <i class="nc-icon nc-istanbul"></i>
                    <p>nc-istanbul</p>
                    <em>\ea33</em><input type="text" maxlength="1" readonly="true" value=""></li>
                  <li>
                    <i class="nc-icon nc-key-25"></i>
                    <p>nc-key-25</p>
                    <em>\ea34</em><input type="text" maxlength="1" readonly="true" value=""></li>
                  <li>
                    <i class="nc-icon nc-laptop"></i>
                    <p>nc-laptop</p>
                    <em>\ea35</em><input type="text" maxlength="1" readonly="true" value=""></li>
                  <li>
                    <i class="nc-icon nc-layout-11"></i>
                    <p>nc-layout-11</p>
                    <em>\ea36</em><input type="text" maxlength="1" readonly="true" value=""></li>
                  <li>
                    <i class="nc-icon nc-lock-circle-open"></i>
                    <p>nc-lock-circle-open</p>
                    <em>\ea37</em><input type="text" maxlength="1" readonly="true" value=""></li>
                  <li>
                    <i class="nc-icon nc-map-big"></i>
                    <p>nc-map-big</p>
                    <em>\ea38</em><input type="text" maxlength="1" readonly="true" value=""></li>
                  <li>
                    <i class="nc-icon nc-minimal-down"></i>
                    <p>nc-minimal-down</p>
                    <em>\ea39</em><input type="text" maxlength="1" readonly="true" value=""></li>
                  <li>
                    <i class="nc-icon nc-minimal-left"></i>
                    <p>nc-minimal-left</p>
                    <em>\ea3a</em><input type="text" maxlength="1" readonly="true" value=""></li>
                  <li>
                    <i class="nc-icon nc-minimal-right"></i>
                    <p>nc-minimal-right</p>
                    <em>\ea3b</em><input type="text" maxlength="1" readonly="true" value=""></li>
                  <li>
                    <i class="nc-icon nc-minimal-up"></i>
                    <p>nc-minimal-up</p>
                    <em>\ea3c</em><input type="text" maxlength="1" readonly="true" value=""></li>
                  <li>
                    <i class="nc-icon nc-mobile"></i>
                    <p>nc-mobile</p>
                    <em>\ea3d</em><input type="text" maxlength="1" readonly="true" value=""></li>
                  <li>
                    <i class="nc-icon nc-money-coins"></i>
                    <p>nc-money-coins</p>
                    <em>\ea3e</em><input type="text" maxlength="1" readonly="true" value=""></li>
                  <li>
                    <i class="nc-icon nc-note-03"></i>
                    <p>nc-note-03</p>
                    <em>\ea3f</em><input type="text" maxlength="1" readonly="true" value=""></li>
                  <li>
                    <i class="nc-icon nc-palette"></i>
                    <p>nc-palette</p>
                    <em>\ea40</em><input type="text" maxlength="1" readonly="true" value=""></li>
                  <li>
                    <i class="nc-icon nc-paper"></i>
                    <p>nc-paper</p>
                    <em>\ea41</em><input type="text" maxlength="1" readonly="true" value=""></li>
                  <li>
                    <i class="nc-icon nc-pin-3"></i>
                    <p>nc-pin-3</p>
                    <em>\ea42</em><input type="text" maxlength="1" readonly="true" value=""></li>
                  <li>
                    <i class="nc-icon nc-planet"></i>
                    <p>nc-planet</p>
                    <em>\ea43</em><input type="text" maxlength="1" readonly="true" value=""></li>
                  <li>
                    <i class="nc-icon nc-refresh-69"></i>
                    <p>nc-refresh-69</p>
                    <em>\ea44</em><input type="text" maxlength="1" readonly="true" value=""></li>
                  <li>
                    <i class="nc-icon nc-ruler-pencil"></i>
                    <p>nc-ruler-pencil</p>
                    <em>\ea45</em><input type="text" maxlength="1" readonly="true" value=""></li>
                  <li>
                    <i class="nc-icon nc-satisfied"></i>
                    <p>nc-satisfied</p>
                    <em>\ea46</em><input type="text" maxlength="1" readonly="true" value=""></li>
                  <li>
                    <i class="nc-icon nc-scissors"></i>
                    <p>nc-scissors</p>
                    <em>\ea47</em><input type="text" maxlength="1" readonly="true" value=""></li>
                  <li>
                    <i class="nc-icon nc-send"></i>
                    <p>nc-send</p>
                    <em>\ea48</em><input type="text" maxlength="1" readonly="true" value=""></li>
                  <li>
                    <i class="nc-icon nc-settings-gear-65"></i>
                    <p>nc-settings-gear-65</p>
                    <em>\ea49</em><input type="text" maxlength="1" readonly="true" value=""></li>
                  <li>
                    <i class="nc-icon nc-settings"></i>
                    <p>nc-settings</p>
                    <em>\ea4a</em><input type="text" maxlength="1" readonly="true" value=""></li>
                  <li>
                    <i class="nc-icon nc-share-66"></i>
                    <p>nc-share-66</p>
                    <em>\ea4b</em><input type="text" maxlength="1" readonly="true" value=""></li>
                  <li>
                    <i class="nc-icon nc-shop"></i>
                    <p>nc-shop</p>
                    <em>\ea4c</em><input type="text" maxlength="1" readonly="true" value=""></li>
                  <li>
                    <i class="nc-icon nc-simple-add"></i>
                    <p>nc-simple-add</p>
                    <em>\ea4d</em><input type="text" maxlength="1" readonly="true" value=""></li>
                  <li>
                    <i class="nc-icon nc-simple-delete"></i>
                    <p>nc-simple-delete</p>
                    <em>\ea4e</em><input type="text" maxlength="1" readonly="true" value=""></li>
                  <li>
                    <i class="nc-icon nc-simple-remove"></i>
                    <p>nc-simple-remove</p>
                    <em>\ea4f</em><input type="text" maxlength="1" readonly="true" value=""></li>
                  <li>
                    <i class="nc-icon nc-single-02"></i>
                    <p>nc-single-02</p>
                    <em>\ea50</em><input type="text" maxlength="1" readonly="true" value=""></li>
                  <li>
                    <i class="nc-icon nc-single-copy-04"></i>
                    <p>nc-single-copy-04</p>
                    <em>\ea51</em><input type="text" maxlength="1" readonly="true" value=""></li>
                  <li>
                    <i class="nc-icon nc-sound-wave"></i>
                    <p>nc-sound-wave</p>
                    <em>\ea52</em><input type="text" maxlength="1" readonly="true" value=""></li>
                  <li>
                    <i class="nc-icon nc-spaceship"></i>
                    <p>nc-spaceship</p>
                    <em>\ea53</em><input type="text" maxlength="1" readonly="true" value=""></li>
                  <li>
                    <i class="nc-icon nc-sun-fog-29"></i>
                    <p>nc-sun-fog-29</p>
                    <em>\ea54</em><input type="text" maxlength="1" readonly="true" value=""></li>
                  <li>
                    <i class="nc-icon nc-support-17"></i>
                    <p>nc-support-17</p>
                    <em>\ea55</em><input type="text" maxlength="1" readonly="true" value=""></li>
                  <li>
                    <i class="nc-icon nc-tablet-2"></i>
                    <p>nc-tablet-2</p>
                    <em>\ea56</em><input type="text" maxlength="1" readonly="true" value=""></li>
                  <li>
                    <i class="nc-icon nc-tag-content"></i>
                    <p>nc-tag-content</p>
                    <em>\ea57</em><input type="text" maxlength="1" readonly="true" value=""></li>
                  <li>
                    <i class="nc-icon nc-tap-01"></i>
                    <p>nc-tap-01</p>
                    <em>\ea58</em><input type="text" maxlength="1" readonly="true" value=""></li>
                  <li>
                    <i class="nc-icon nc-tie-bow"></i>
                    <p>nc-tie-bow</p>
                    <em>\ea59</em><input type="text" maxlength="1" readonly="true" value=""></li>
                  <li>
                    <i class="nc-icon nc-tile-56"></i>
                    <p>nc-tile-56</p>
                    <em>\ea5a</em><input type="text" maxlength="1" readonly="true" value=""></li>
                  <li>
                    <i class="nc-icon nc-time-alarm"></i>
                    <p>nc-time-alarm</p>
                    <em>\ea5b</em><input type="text" maxlength="1" readonly="true" value=""></li>
                  <li>
                    <i class="nc-icon nc-touch-id"></i>
                    <p>nc-touch-id</p>
                    <em>\ea5c</em><input type="text" maxlength="1" readonly="true" value=""></li>
                  <li>
                    <i class="nc-icon nc-trophy"></i>
                    <p>nc-trophy</p>
                    <em>\ea5d</em><input type="text" maxlength="1" readonly="true" value=""></li>
                  <li>
                    <i class="nc-icon nc-tv-2"></i>
                    <p>nc-tv-2</p>
                    <em>\ea5e</em><input type="text" maxlength="1" readonly="true" value=""></li>
                  <li>
                    <i class="nc-icon nc-umbrella-13"></i>
                    <p>nc-umbrella-13</p>
                    <em>\ea5f</em><input type="text" maxlength="1" readonly="true" value=""></li>
                  <li>
                    <i class="nc-icon nc-user-run"></i>
                    <p>nc-user-run</p>
                    <em>\ea60</em><input type="text" maxlength="1" readonly="true" value=""></li>
                  <li>
                    <i class="nc-icon nc-vector"></i>
                    <p>nc-vector</p>
                    <em>\ea61</em><input type="text" maxlength="1" readonly="true" value=""></li>
                  <li>
                    <i class="nc-icon nc-watch-time"></i>
                    <p>nc-watch-time</p>
                    <em>\ea62</em><input type="text" maxlength="1" readonly="true" value=""></li>
                  <li>
                    <i class="nc-icon nc-world-2"></i>
                    <p>nc-world-2</p>
                    <em>\ea63</em><input type="text" maxlength="1" readonly="true" value=""></li>
                  <li>
                    <i class="nc-icon nc-zoom-split"></i>
                    <p>nc-zoom-split</p>
                    <em>\ea64</em><input type="text" maxlength="1" readonly="true" value=""></li>
                  <!-- list of icons here with the proper class-->
                </ul>
              </section>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>
<script>
  export default {}
</script>
<style>

</style>
